---
title: 'Barchart talks about falling natgas prices'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'barchart-talks-about-falling-natgas-prices'
description: ''
coverImage: '/images/rfp-brand-kzMT.png'
publishedAt: '2023-05-24T16:06:13.783Z'
---

[https://www.barchart.com/story/news/17125405/nat-gas-prices-decline-on-mild-weather-outlook](https://www.barchart.com/story/news/17125405/nat-gas-prices-decline-on-mild-weather-outlook)

