---
title: 'Latest Oil & Gas Rig Count'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'latest-oil-gas-rig-count'
description: ''
coverImage: '/images/rfp-brand-qwmt-QxNj.webp'
publishedAt: '2023-10-13T17:04:16.238Z'
---

Baker Hughes on Friday reported that the number of active U.S. rigs drilling for oil rose by 4 to 501 this week. That followed three consecutive weeks of declines. The total active U.S. rig count, which includes those drilling for natural gas, also climbed by 3 to stand at 622, according to Baker Hughes. [Oil prices continued to trade higher in Friday dealings ](https://www.marketwatch.com/story/oil-prices-jump-3-as-middle-east-tensions-rise-with-israel-ordering-mass-evacuations-in-gaza-d5fcebdd?mod=futures-movers&mod=article_inline)as worsening developments in the Israel-Gaza war raised the [risk of disruptions](https://www.marketwatch.com/story/israel-gaza-war-scenarios-what-might-lift-oil-prices-to-95-100-and-115-a-barrel-f494e9fa?mod=commodities-corner&mod=article_inline) to the oil market in the Middle East. November West Texas Intermediate crude was up $4.38, or 5.3%, at $87.29 a barrel on the New York Mercantile Exchange.

