---
title: 'More Power lines for California'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'more-power-lines-for-california'
description: ''
coverImage: '/images/rfp-brand-kwMD.png'
publishedAt: '2023-05-22T20:18:36.852Z'
---

Hoping they build them below ground and not above ground through densely wooded areas….

[https://www.reuters.com/business/energy/california-grid-operator-signs-off-73-billion-power-lines-2023-05-19/](https://www.reuters.com/business/energy/california-grid-operator-signs-off-73-billion-power-lines-2023-05-19/)

