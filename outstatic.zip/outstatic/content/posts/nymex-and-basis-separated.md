---
title: 'NYMEX and Basis Separated'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'nymex-and-basis-separated'
description: ''
coverImage: '/images/rfp-brand-UxOT.png'
publishedAt: '2023-04-13T16:24:47.761Z'
---

4-13-23

Month NYMEX, PG&E CG Basis, SoCal CG Basis

May-23 $2.093 $3.458 $2.916

Jun-23 $2.267 $3.478 $3.347

Jul-23 $2.489 $4.337 $5.488

Aug-23 $2.547 $4.712 $6.376

Sep-23 $2.526 $4.508 $5.222

Oct-23 $2.619 $4.151 $2.923

Nov-23 $3.017 $4.260 $3.521

Dec-23 $3.472 $5.286 $7.494

Jan-24 $3.713 $5.121 $7.309

Feb-24 $3.627 $4.806 $6.299

Mar-24 $3.337 $2.727 $3.603

Apr-24 $3.062 $2.203 $1.666

May-24 $3.065 $1.553 $1.448

Jun-24 $3.207 $1.689 $1.649

Jul-24 $3.347 $2.886 $3.605

Aug-24 $3.383 $2.911 $3.645

Sep-24 $3.347 $2.534 $3.524

Oct-24 $3.424 $2.122 $1.623

Nov-24 $3.810 $2.970 $3.824

Dec-24 $4.274 $3.996 $5.520

Jan-25 $4.572 $3.831 $5.463

Feb-25 $4.438 $3.516 $5.090

Mar-25 $4.078 $1.437 $3.361

Apr '25 $3.684 $2.006 $2.195

