---
title: 'THE One Minute Energy Report for...'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'the-one-minute-energy-report-for'
description: ''
coverImage: '/images/rfp-brand-qwmt-UwMj.webp'
publishedAt: '2023-10-17T16:16:39.916Z'
---

***10/17/23***

***\#NYMEX #NYMEXfallingfurther #NaturalGas #Energy #PG&ECGBasisUp #SoCalCGBasisUpStrong #Weather #LNGExportsIncreasing***

***NYMEX***\* – Yesterday’s close = $3.10. Today’s open = $3.12, high = $3.13, low = $3.02, currently sitting @ $3.03. Nov ’23 is down as much as $0018 so far today. NYMEX prices are down approximately $0.35 from 1 week ago and down approximately $3.45 from 1 year ago. \*

***NYMEX CALENDAR ESTIMATES***\* - $3.29 for balance of 2023, $3.54 for 2024, $4.06 for 2025. \*

***RESISTANCE***\* - Starting @ $3.20. ****SUPPORT**** \- Starting @ $3.02, followed by $2.95. The driving factors continue to be bearish. \*

***PRODUCTION & DEMAND***\* – Production = 101.3BCF/D, down 1.2Bcf from the previous year. Demand = 95.8BCF/D, down 6.2Bcf from the previous year. \*

\*\*RIG COUNT – \*\**Last week’s rig count = + 4 for oil with a total of 501 active oil rigs. Compare that to 610 oil rigs 1 year ago. Last week’s natural gas rig count = - 1 for a total of 117 active natural gas rigs. Compare that to 157 natural gas rigs 1 year ago. *

***BASIS***\* – PG&E CG is up again today but not nearly as much as SoCal Basis is today. Not a good day to lock in Basis. \*

***WEATHER***\* – Hot temperatures remain in the SW. Pleasant temperatures throughout the rest of the US. \*

***STORAGE***\* – From 10-12-23 = 84Bcf. We’re now 316Bcf above last year at this time and only 163Bcf above the 5-year average of 3,366Bcf.\*

**Indicative Fixed Prices out of Nov ‘23 **

PG&E CG SOCAL CG SoCal Border (+ $0.53 BTS)

1 MONTH $7.57 $10.38 $8.87

3 MONTHS $9.50 $12.05 $10.64

6 MONTHS $7.61 $8.58 $7.46

12 MONTHS $6.70 $7.40 $5.79

24 MONTHS $6.36 $7.18 $5.89

Winter Strips (Nov ’23 – March ‘24)

$9.15 $11.62 $9.69

Summer Strip (April ’24 – Aug ‘24)

$5.39 $6.05 $4.24

