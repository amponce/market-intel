---
title: 'Aliso Canyon Storage Update'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'aliso-canyon-storage-update'
description: ''
coverImage: '/images/rfp-brand-qwmt-g5ND.webp'
publishedAt: '2023-09-01T02:51:13.380Z'
---

Today, the CPUC approved increasing the Aliso Canyon storage capacity from 41Bcf to 68Bcf. This could alleviate high OFO days in the short term as well as apply downward pressure on winter basis for CA markets.

