---
title: 'End of Week Note'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'end-of-week-note'
description: ''
coverImage: '/images/rfp-brand-qwmt-gymj-YyOT.webp'
publishedAt: '2023-10-06T18:06:58.998Z'
---

Between a below estimate storage injection, a drop in daily production, extended heat through the SW/TX/Gulf regions, and more locally, SoCalGas delaying Aliso Canyon injections for another 2 weeks and recent SoCal Border curtailments, we're seeing the highest delivered prices since Feb '23.

And here is a prime example of how natural gas drives power prices here in CA. CAISO prices are up over $81 to end this week.

