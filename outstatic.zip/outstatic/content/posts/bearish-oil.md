---
title: 'Bearish Oil'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'bearish-oil'
description: 'After an initially subdued reaction to yet another crude oil build in the U.S. on Thursday'
coverImage: '/images/natural-gas-v-Y3OD.png'
publishedAt: '2023-02-24T18:44:12.215Z'
---

After an initially subdued reaction to yet another crude oil build in the U.S. on Thursday, oil prices fell on Friday morning as bearish sentiment built. Speculation of further Russian production cuts and a rebound in Chinese demand had held oil prices higher, but inflation fears and continued inventory builds eventually sent prices lower.

