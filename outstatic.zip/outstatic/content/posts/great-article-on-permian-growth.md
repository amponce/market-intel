---
title: 'Great article on Permian growth'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'great-article-on-permian-growth'
description: ''
coverImage: ''
publishedAt: '2023-10-27T14:47:39.025Z'
---

[https://rbnenergy.com/omg-the-build-out-of-permian-gas-processing-capacity-isnt-over-not-by-a-long-shot](https://rbnenergy.com/omg-the-build-out-of-permian-gas-processing-capacity-isnt-over-not-by-a-long-shot)

