---
title: 'Today''s Indicative Fixed Price & Market Intel'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'todays-indicative-fixed-price-market-intel'
description: ''
coverImage: '/images/rfp-brand-qwmt-gymj-g0NT.webp'
publishedAt: '2023-09-19T17:19:56.275Z'
---

*9-19-23*

*NYMEX is down a few cents from yesterday. The open @ $2.87, high@ $2.87, low @ $2.71, now sitting @ $2.85. Ever so slightly green through June ’25. *

*NYMEX prices are up $0.25 from 1 week ago and down $4.90 from 1 year ago. *

*Latest NYMEX 2023 NYMEX average estimated @ $3.04. $3.41 for 2024. $3.97 for 2025.*

*The national weather chart shows cooler temps moving across the regions for the next few days. *

*Warmer temperatures forecasted in the 6 – 10-day forecast.*

*Resistance at $2.80. Blew right past that.*

*Support at $2.60. Long way off.*

*NatGas averages for last week: Production average = 101.9BCF/D, down 0.3Bcf/D from the previous week.*

*Total Demand average = 97.8BCF/D. Down 1.0Bcf from the previous week.*

*PG&E and SoCal Basis prices are both down strong today. *

- PG&E CG SOCAL CG\*

<!-- -->

*Start Month: Oct ‘23*

*1 MONTH $4.97 $5.16*

*3 MONTHS $6.71 $7.32*

*6 MONTHS $7.00 $7.54*

*12 MONTHS $6.08 $6.51*

*24 MONTHS $5.99 $6.50*

*Winter Strips (Nov ’23 – March ‘24) *

*$7.39 $8.00*

*Summer Strip (April ’24 – Aug ‘24)*

*$5.09 $5.35*

