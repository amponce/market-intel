---
title: 'Maintenance on the Wheeler pipeline was completed ahead of schedule.  SoCal Basis is falling quickly in response.   '
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'maintenance-on-the-wheeler-pipeline-was-completed-ahead-of-schedule-socal-basis-is-falling-quickly-in-response'
description: ''
coverImage: '/images/rfp-brand-MzNj.png'
publishedAt: '2023-08-10T17:07:37.981Z'
---

Maintenance on the Wheeler pipeline was completed ahead of schedule. SoCal Basis is falling quickly in response.

