---
title: 'Saudi Arabia, Russia extend voluntary oil cuts to year-end, markets jump'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'saudi-arabia-russia-extend-voluntary-oil-cuts-to-year-end-markets-jump'
description: ''
coverImage: '/images/rfp-brand-qwmt-AzMz.webp'
publishedAt: '2023-09-06T17:52:34.234Z'
---

[https://www.reuters.com/business/energy/saudi-arabia-extends-voluntary-oil-output-cut-1-mln-bpd-end-2023-2023-09-05/](https://www.reuters.com/business/energy/saudi-arabia-extends-voluntary-oil-output-cut-1-mln-bpd-end-2023-2023-09-05/)

