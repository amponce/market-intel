---
title: 'NYMEX is cheap!!'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'nymex-is-cheap'
description: ''
coverImage: '/images/natural-gas-contracts-QwOT.png'
publishedAt: '2023-03-07T19:11:34.022Z'
---

Just look at the current lows. We're close to the bottom of the market for the past (nearly) 30 years….<br>

Remember, greed is good but gluttony kills.<br>

Those waiting for sub $2 NYMEX….go ahead and wait.

![chart, line chart](https://media.licdn.com/dms/image/C5622AQEeqRumYVVRlg/feedshare-shrink_2048_1536/0/1678219119716?e=1681344000&v=beta&t=qnIhZP9WszS_-YbJiGbB33GOrn21Aduxa23R3NGdEKQ)

