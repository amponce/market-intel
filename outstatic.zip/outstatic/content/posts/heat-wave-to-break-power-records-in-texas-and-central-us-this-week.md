---
title: 'Heat wave to break power records in Texas and central US this week'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'heat-wave-to-break-power-records-in-texas-and-central-us-this-week'
description: ''
coverImage: '/images/rfp-brand-QzOT.png'
publishedAt: '2023-08-22T20:09:41.565Z'
---

[https://www.reuters.com/business/energy/heat-wave-break-power-records-texas-central-us-this-week-2023-08-21/](https://www.reuters.com/business/energy/heat-wave-break-power-records-texas-central-us-this-week-2023-08-21/)

