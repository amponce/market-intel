---
title: 'Natgas dropping hard so far this year'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'natgas-dropping-hard-so-far-this-year'
description: 'Natural-gas prices have dropped more than 65% since mid-December and this week hit their lowest level'
coverImage: '/images/rfp-brand-E0Mz.png'
publishedAt: '2023-02-24T18:48:40.290Z'
---

Natural-gas prices have dropped more than 65% since mid-December and this week hit their lowest level since 2020’s pandemic lockdown, leading producers to throttle back drilling in a dramatic turn in the market for the heating and power-generation fuel.

Expensive natural gas was a major contributor to inflation over the past two years, pushing up the price of electricity and staying warm as well as manufacturing costs for fertilizer, steel, glass, aluminum, plastic and cardboard.

