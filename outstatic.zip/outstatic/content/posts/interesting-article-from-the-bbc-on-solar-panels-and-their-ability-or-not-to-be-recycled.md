---
title: 'Interesting article from the BBC on solar panels and their ability, or not, to be recycled'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'interesting-article-from-the-bbc-on-solar-panels-and-their-ability-or-not-to-be-recycled'
description: ''
coverImage: '/images/rfp-brand-Q2OT.png'
publishedAt: '2023-06-05T13:06:09.798Z'
---

[https://www.bbc.com/news/science-environment-65602519](https://www.bbc.com/news/science-environment-65602519)

