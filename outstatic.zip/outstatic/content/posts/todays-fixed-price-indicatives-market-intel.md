---
title: 'THE One Minute Energy Report '
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'todays-fixed-price-indicatives-market-intel'
description: ''
coverImage: '/images/rfp-brand-qwmt-cxMD.webp'
publishedAt: '2023-10-13T15:18:55.584Z'
---

***10/13/23***

***\#NYMEX #NYMEXfallingfurther #NaturalGas #Energy #DropinDemandComing #CABasis ***

***NYMEX***\* – Today’s open = $3.34, high = $3.34, low = $3.21, currently sitting @ $3.23. Nov ’23 is down as much as $0.13 so far today. NYMEX prices are up approximately $0.30 from 1 week ago. Down approximately $3.30 from 1 year ago. \*

***NYMEX CALENDAR ESTIMATES***\* - $3.49 for balance of 2023, $3.63 for 2024, $4.08 for 2025. \*

***RESISTANCE***\* - Starting @ $3.55. ****SUPPORT**** \- Starting @ $3.26. We broke through the first and second ($3.21) support levels. We’ll see how much further NYMEX falls. The driving factors moving in our favor…..for now.\*

***PRODUCTION & DEMAND***\* - Production = 101.3BCF/D, up 0.4Bcf from last week, up 0.3Bcf from the previous year. Demand = 95.8BCF/D, up 1.4Bcf from last week, down 6.3Bcf from the previous year. \*

\*\*RIG COUNT – \*\**Last week’s rig count fell for a third straight week. Overall, the rig count is down 19% from this time last year, and the lowest since Feb ’22. Next rig count comes out 10-13-23, later this morning. We’ll report that count separately later today. *

***BASIS***\* – PG&E CG continues to fall penny by penny. SoCal Basis spends a second day being bullish. This bull run SHOULD retreat once we start injecting into Aliso Canyon 10-21-23. \*

***LNG***\* – Exports = 12.5Bcf/D.\*

***WEATHER***\* – Cooler temperatures across the US with rain in the Mid-Con, sunshine for the rest of us. Warmer than normal temperatures from the Pac NW through the Mid-Con on the 6 – 10-day forecast should keep any early heating demand at bay. Bearish forecast. \*

***STORAGE***\* – From 10-12-23 = 84Bcf. We’re now 316Bcf above last year at this time and only 163Bcf above the 5-year average of 3,366Bcf. Estimates for the end of Injection Season range from $3.83Bcf – 3.94Bcf. Estimates for the start of 2024 Injection Season range from 1.66Bcf – 2.08Bcf.\*

**Indicative Fixed Prices out of Nov ‘23 **

PG&E CG SOCAL CG SoCal Border (+ $0.53 BTS)

1 MONTH $6.38 $8.48 $6.97

3 MONTHS $8.60 $10.15 $8.74

6 MONTHS $7.50 $8.32 $7.26

12 MONTHS $6.40 $7.10 $5.59

24 MONTHS $6.21 $6.95 $5.89

Winter Strips (Nov ’23 – March ‘24)

$8.01 $9.10 $7.49

Summer Strip (April ’24 – Aug ‘24)

$5.19 $5.75 $4.09

