---
title: 'DoE Heating Costs and Cost Comparisons'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'doe-heating-costs-and-cost-comparisons'
description: 'Electric heating costs 46% more than gas.'
coverImage: '/images/marketupdatefeb9-g4Nz.png'
publishedAt: '2023-02-09T15:41:30.685Z'
---

![null](https://substackcdn.com/image/fetch/w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F4006d44b-609c-466f-a5a4-d011f7571470_1898x1058.jpeg)![null](https://substackcdn.com/image/fetch/w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9f00e21c-28c0-4c13-8457-33cec1423aa8_1904x1062.jpeg)

