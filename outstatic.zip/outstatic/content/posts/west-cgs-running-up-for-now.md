---
title: 'West CGs running up for now'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'west-cgs-running-up-for-now'
description: ''
coverImage: '/images/rfp-brand-M2ND.png'
publishedAt: '2023-02-27T16:58:54.241Z'
---

While prompt month gas slipped below $2.00, strong short-term weather demand and continued momentum by Freeport LNG toward a full restart combined to fuel a recovery late last week.

The March '23 NYMEX contract rolled off the board at $2.45, up $0.13 on the day and up $0.17 from the prior week.

Prices in California soared as high as $17.750 this week.

PG&E CG ran up $4.64 week/week to average $11.11. SoCal CG jumped $3.81 to average $10.38.

