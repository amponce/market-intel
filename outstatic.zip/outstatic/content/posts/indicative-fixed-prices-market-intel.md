---
title: 'Indicative Fixed Prices & Market Intel'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'indicative-fixed-prices-market-intel'
description: ''
coverImage: '/images/rfp-brand-k3OD.png'
publishedAt: '2023-08-22T14:56:35.051Z'
---

8-22-23

NYMEX prices are down today, as much as $0.08 on the prompt month, moving as low as $2.55 and as high as $2.63. We’re down $0.20 from 1 week ago and down $6.75 from 1 year ago.

PG&E Basis and SoCal Basis are also down today, ranging from $0.05 to $0.15, depending on the month.

Bulls – very little to be bullish about right now. Resistance at $2.72 - $2.82.

Bears – weather and falling cooling demand. Support at $2.53 - $2.50.

The driving factors look to be setting up some good hedging opportunities over the next few weeks. May want to think about buying NYMEX and Basis separately to capture an even greater collapse in the two pricing pieces.

PG&E CG SOCAL CG

Start Month: Sep ‘23

1 MONTH $5.40 $6.15

3 MONTHS $5.80 $6.75

6 MONTHS $7.20 $8.40

12 MONTHS $6.20 $7.00

24 MONTHS $6.05 $6.80

Winter Strips (Nov ’23 – March ‘24)

$7.65 $8.80

Summer Strip (May ’24 – Aug ‘24)

$5.05 $5.50

