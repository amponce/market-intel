---
title: 'Indicative Fixed Prices - April '
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/3916436?v=4'
slug: 'indicative-fixed-prices-april'
description: 'Market intel for 2-22-23
Start month -  April 23'
coverImage: '/images/news-market-intel-k1Nj.png'
publishedAt: '2023-02-22T18:03:37.914Z'
---

![](/images/screenshot-2023-02-22-at-10.50.08-am-AzOT.png)<br>

