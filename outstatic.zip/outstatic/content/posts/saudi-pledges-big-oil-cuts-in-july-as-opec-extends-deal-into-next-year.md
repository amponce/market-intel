---
title: 'Saudi pledges big oil cuts in July as OPEC extends deal into next year...'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'saudi-pledges-big-oil-cuts-in-july-as-opec-extends-deal-into-next-year'
description: ''
coverImage: '/images/rfp-brand-kyMz.png'
publishedAt: '2023-06-05T12:58:53.392Z'
---

[https://www.reuters.com/business/energy/opec-meets-debate-production-quotas-new-cut-sources-2023-06-04/](https://www.reuters.com/business/energy/opec-meets-debate-production-quotas-new-cut-sources-2023-06-04/)

