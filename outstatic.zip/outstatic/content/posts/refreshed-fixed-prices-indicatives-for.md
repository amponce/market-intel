---
title: 'Refreshed Fixed Prices Indicatives for...'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'refreshed-fixed-prices-indicatives-for'
description: ''
coverImage: ''
publishedAt: '2023-10-23T16:51:52.606Z'
---

10-23-23

**Indicative Fixed Prices out of Nov ‘23 **

PG&E CG SOCAL CG SoCal Border (+ $0.53 BTS)

1 MONTH $6.70 $9.40 $6.90

3 MONTHS $9.00 $11.22 $9.58

6 MONTHS $7.80 $9.09 $7.98

12 MONTHS $6.55 $7.75 $6.50

24 MONTHS $6.35 $7.64 $5.93

Winter Strips (Nov ’23 – March ‘24)

$8.35 $9.90 $8.56

Summer Strip (April ’24 – Aug ‘24)

$5.20 $6.05 $4.27

