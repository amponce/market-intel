---
title: 'Interesting article link'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'interesting-article-link'
description: ''
coverImage: '/images/rfp-brand-A3Mj.png'
publishedAt: '2023-03-27T17:44:40.155Z'
---

[https://thehill.com/opinion/energy-environment/3913117-oliver-stone-is-half-right-regarding-nuclear-energy-and-climate-change/](https://thehill.com/opinion/energy-environment/3913117-oliver-stone-is-half-right-regarding-nuclear-energy-and-climate-change/)

