---
title: 'What were we saying about reliability??'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'what-were-we-saying-about-reliability'
description: ''
coverImage: '/images/rfp-brand-qwmt-gymj-I3Nz.webp'
publishedAt: '2023-09-08T17:38:26.597Z'
---

[https://www.reuters.com/markets/commodities/us-wind-power-generation-breaks-out-summer-doldrums-2023-09-08/](https://www.reuters.com/markets/commodities/us-wind-power-generation-breaks-out-summer-doldrums-2023-09-08/)

