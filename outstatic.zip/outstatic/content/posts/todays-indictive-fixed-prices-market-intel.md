---
title: 'Today''s Indictive Fixed Prices & Market Intel'
status: 'published'
author:
  name: 'Sean Dookie'
  picture: 'https://avatars.githubusercontent.com/u/124637922?v=4'
slug: 'todays-indictive-fixed-prices-market-intel'
description: ''
coverImage: '/images/rfp-brand-c2MD.png'
publishedAt: '2023-05-31T15:47:43.961Z'
---

5-31-23

NYMEX continues to be bearish. Mild weather forecasts, well above storage injection projections, and below normal demand are the driving factors and should continue to be for the next week or two.

Ca Basis continues to fall but we remain well above the historical range for both PG&E CG and SoCal CG.

START MONTH – JULY ’23

PG&E CG SOCAL CG

1 MONTH $4.73 $6.45

3 MONTHS $4.89 $7.06

6 MONTHS $5.35 $6.95

12 MONTHS $5.40 $6.61

24 MONTHS $5.56 $6.71

Summer Strip (June ’23 – Oct ‘23)

$4.91 $6.61

Winter Strips (Nov ’23 – March ‘24)

$6.39 $7.76

