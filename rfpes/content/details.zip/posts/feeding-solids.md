---
title: 'Feeding Solids'
status: 'published'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
slug: 'feeding-solids'
description: ''
coverImage: '/images/kateryna-hliznitsova-i11jfrj_sfg-unsplash-Q5OT.jpg'
tags: []
publishedAt: '2023-11-26T20:04:53.000Z'
---

### [Spill-proof snack containers](https://amzn.to/3uy2QUP)

[![spill-proof snack containers](https://www.hazelsprout.com/_next/image?url=%2Fimages%2Fsnack-czMD.png&w=750&q=75)](https://amzn.to/3uy2QUP)