---
affiliateSource: [{"label":"Amazon","value":"amazon"}]
ageRange: [{"label":"6–12 months","value":"6–12Months"},{"label":"12–18 months","value":"12–18Months"},{"label":"18–24 months","value":"18–24Months"}]
tags: [{"label":"Kitchen","value":"kitchen"},{"value":"amazon","label":"Amazon"},{"label":"Feeding","value":"feeding"}]
itemPrice: '299'
productLink: 'https://amzn.to/3Q7T1W2'
coverImage: '/images/highchair-Q3Nz.png'
description: ''
slug: 'baby-jogger-city-bistro-high-chair'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'City Bistro High Chair'
publishedAt: '2023-10-12T03:57:19.666Z'
---

**Compact Design**: Folds easy storage with tray conveniently clipping to the back.

**Adaptable & Safe**: Features 4 height adjustments and a secure 5-point harness for baby's safety.

