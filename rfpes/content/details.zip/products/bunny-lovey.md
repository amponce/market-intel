---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
tags: [{"value":"amazon","label":"Amazon"},{"value":"bedtime","label":"Bedtime"},{"value":"toys","label":"Toys"},{"value":"gifts","label":"Gifts"},{"value":"nursery","label":"Nursery"}]
itemPrice: '25'
productLink: 'https://amzn.to/49RKONt'
coverImage: '/images/bun-AyNj.png'
description: ''
slug: 'bunny-lovey'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Bunny Lovey'
publishedAt: '2023-11-08T04:41:02.261Z'
---

• 5 x 13 x 13.5 inches, suitable for all ages, machine washable