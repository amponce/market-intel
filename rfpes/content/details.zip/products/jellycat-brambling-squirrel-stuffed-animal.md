---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
tags: [{"value":"toys","label":"Toys"},{"value":"amazon","label":"Amazon"},{"value":"gifts","label":"Gifts"}]
itemPrice: '27.5'
productLink: 'https://amzn.to/3QnRHhM'
coverImage: '/images/squi-QyMD.png'
description: ''
slug: 'jellycat-brambling-squirrel-stuffed-animal'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Jellycat Squirrel Stuffed Animal'
publishedAt: '2023-10-20T03:33:41.731Z'
---

• **7 inches tall**.

• **Good for all ages**: Suitable for use from birth, making it an ideal gift for newborns.

• **Quality Design**: Designed by Jellycat in London, UK.

