---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"}]
tags: [{"label":"Bath","value":"bath"},{"value":"amazon","label":"Amazon"}]
itemPrice: '8.99'
productLink: 'https://amzn.to/3FingUd'
coverImage: '/images/bath-E2ND.png'
description: ''
slug: 'ubbi-baby-bathtub-spout-guard'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Bathtub Spout Guard'
publishedAt: '2023-10-17T03:38:55.275Z'
---

• **Safety First**: Soft silicone bath spout guard designed to prevent head bumps and injuries during baby's bath time.

• **Universal Fit**: Compatible with most bathtub spouts

• **Easy Installation**: Simply slide it over your existing spout

