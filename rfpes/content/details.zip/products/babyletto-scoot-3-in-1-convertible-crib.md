---
tags: [{"value":"bedtime","label":"Bedtime"},{"label":"Nursery","value":"nursery"},{"value":"amazon","label":"Amazon"}]
itemPrice: '399'
productLink: 'https://amzn.to/3ZXUwcP'
coverImage: '/images/crib-Y5Mj.png'
description: ''
slug: 'babyletto-scoot-3-in-1-convertible-crib'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Babyletto Convertible Crib'
publishedAt: '2023-10-18T03:15:39.024Z'
---

• **Stylish & Versatile Design**: The Scoot crib offers a mid-century modern aesthetic with angular feet and contrasting lines, capable of converting into a toddler bed and daybed.

• **GREENGUARD Gold Certified**

• **4 adjustable mattress positions**

