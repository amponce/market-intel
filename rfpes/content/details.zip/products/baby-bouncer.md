---
title: 'Baby bouncer'
status: 'published'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
slug: 'baby-bouncer'
description: ''
coverImage: '/images/bouncer-cwMT.png'
productLink: 'https://amzn.to/47WLxev'
itemPrice: '209'
tags: [{"value":"amazon","label":"Amazon"},{"value":"nursery","label":"Nursery"},{"value":"home","label":"Home"},{"value":"gifts","label":"Gifts"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"}]
affiliateSource: [{"value":"amazon","label":"Amazon"}]
publishedAt: '2023-12-01T04:51:39.593Z'
---

• Ergonomic

• Natural rocking

• 8–29 lbs, from 21 in