---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"label":"Other","value":"other"}]
tags: [{"value":"home","label":"Home"},{"value":"nursery","label":"Nursery"},{"value":"amazon","label":"Amazon"}]
itemPrice: '799'
productLink: 'https://amzn.to/3Maaw5B'
coverImage: '/images/chair-IzOT.png'
description: ''
slug: 'babyletto-sigi-electronic-power-recliner-glider'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Babyletto Power Recliner & Glider'
publishedAt: '2023-10-20T03:13:17.687Z'
---

• **Multi-Functionality**: The Sigi is a versatile nursery recliner that glides, electronically reclines, and comes with a built-in USB A/C charger.

• **GREENGUARD Gold certified**

•** Stain-resistant and water-repellent**

