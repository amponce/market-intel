---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"}]
tags: [{"value":"bath","label":"Bath"},{"value":"amazon","label":"Amazon"}]
itemPrice: '14.99'
productLink: 'https://amzn.to/3EZpQy8'
coverImage: '/images/mushie-YwNj.png'
description: ''
slug: 'mushie-baby-bath-rinse-cup-100-food-grade-silicone'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Baby Bath Rinse Cup'
publishedAt: '2023-10-17T03:57:35.031Z'
---

• **Food-grade Silicone**: the Mushie Bath Rinse Cup features a textured exterior and convenient handle for a secure grip, making it easier to rinse off the soap.

• **28 fl. oz capacity**

