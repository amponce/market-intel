---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"},{"value":"other","label":"Other"}]
tags: [{"value":"amazon","label":"Amazon"},{"value":"home","label":"Home"},{"value":"bedtime","label":"Bedtime"},{"value":"nursery","label":"Nursery"}]
itemPrice: '26.39'
productLink: 'https://amzn.to/3MxXLSx'
coverImage: '/images/blackout-c0MD.png'
description: ''
slug: 'blackout-curtains'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Blackout Curtains'
publishedAt: '2023-11-08T04:35:06.659Z'
---

• **Portable blackout curtain** that blocks sunlight, UV rays, and reduces noise, complete with a travel bag for on-the-go use.

• **Customizable size** with Velcro edges, made from 100% polyester in Black, machine-washable for easy care.

