---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
tags: [{"value":"amazon","label":"Amazon"},{"value":"toys","label":"Toys"},{"value":"gifts","label":"Gifts"}]
itemPrice: '74'
productLink: 'https://amzn.to/3FGIGdD'
coverImage: '/images/qual-k5Mj.png'
description: ''
slug: 'handmade-koala-doll'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Handmade Koala Doll'
publishedAt: '2023-11-02T03:23:11.442Z'
---

• **Quinn the Koala**: A hand-knit doll that helps feed children in need, with each purchase providing 10 meals through global charities. Quinn is crafted with natural cotton and available in two sizes, featuring details for an heirloom-quality toy.

• **Ethical Commitment**: cuddle+kind supports artisans with fair trade employment, winning multiple awards for their hand-knit stuffed animals and offering a Happiness Guarantee with easy returns or replacements.

