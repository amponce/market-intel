---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
tags: [{"value":"amazon","label":"Amazon"},{"value":"toys","label":"Toys"},{"value":"gifts","label":"Gifts"}]
itemPrice: '35'
productLink: 'https://amzn.to/47FOakO'
coverImage: '/images/dinoe-I3OD.png'
description: ''
slug: 'dinosaur-stuffed-animal'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Dinosaur Stuffed Animal'
publishedAt: '2023-11-08T04:56:55.691Z'
---

• 4.25 x 6.5 inches, made of 100% polyester, suitable from birth, spot clean recommended, designed in London, UK.