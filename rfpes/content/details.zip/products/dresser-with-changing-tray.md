---
title: 'Dresser with changing tray'
status: 'published'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
slug: 'dresser-with-changing-tray'
description: ''
coverImage: '/images/dresser-gzNj.png'
productLink: 'https://amzn.to/3R67MI6'
itemPrice: '399'
tags: [{"value":"amazon","label":"Amazon"},{"value":"home","label":"Home"},{"value":"nursery","label":"Nursery"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
affiliateSource: [{"value":"amazon","label":"Amazon"}]
publishedAt: '2023-12-01T05:05:20.654Z'
---

• An essential piece for modern nurseries, boasting natural curves and contrasting elements.

• GREENGUARD GOLD certified