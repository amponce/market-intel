---
tags: [{"value":"nursery","label":"Nursery"},{"value":"home","label":"Home"},{"value":"bedtime","label":"Bedtime"},{"value":"amazon","label":"Amazon"}]
itemPrice: '299'
productLink: 'https://amzn.to/3QmK77d'
coverImage: '/images/crib2-QwNj.png'
description: ''
slug: 'newton-baby-travel-crib-and-play-yard-100-breathable-washable'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Newton Baby Travel Crib and Play Yard'
publishedAt: '2023-10-19T04:22:01.248Z'
---

• **Safety & Comfort**: Features patented Wovenaire technology for 100% breathability. It comes with the thickest and only washable mattress in the market for optimal support and includes a breathable muslin sheet.

• **Spacious & Travel-friendly**: Offers 2x larger surface area than leading competitors for better sleep and play.

• **GREENGUARD Gold certified**

