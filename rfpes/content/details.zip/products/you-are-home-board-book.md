---
title: 'You Are Home board book'
status: 'published'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
slug: 'you-are-home-board-book'
description: ''
coverImage: '/images/you-are-home-IwMz.png'
productLink: 'https://amzn.to/414TbkS'
itemPrice: '7.46'
tags: [{"value":"amazon","label":"Amazon"},{"value":"gifts","label":"Gifts"},{"value":"books","label":"Books"}]
ageRange: [{"value":"0–6Months","label":"0–6 months"},{"value":"6–12Months","label":"6–12 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"},{"value":"2–3Years","label":"2–3 years"},{"value":"3+Years","label":"3+ years"}]
affiliateSource: [{"value":"amazon","label":"Amazon"}]
publishedAt: '2023-12-03T19:27:55.243Z'
---

• 