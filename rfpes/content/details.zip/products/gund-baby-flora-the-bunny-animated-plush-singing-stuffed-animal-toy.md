---
affiliateSource: [{"value":"amazon","label":"Amazon"}]
ageRange: [{"value":"6–12Months","label":"6–12 months"},{"value":"0–6Months","label":"0–6 months"},{"value":"12–18Months","label":"12–18 months"},{"value":"18–24Months","label":"18–24 months"}]
tags: [{"value":"toys","label":"Toys"},{"value":"gifts","label":"Gifts"},{"value":"amazon","label":"Amazon"}]
itemPrice: '40'
productLink: 'https://amzn.to/3Qdrt0f'
coverImage: '/images/gund-AzMz.png'
description: ''
slug: 'gund-baby-flora-the-bunny-animated-plush-singing-stuffed-animal-toy'
author:
  name: 'Laura Poncé'
  picture: 'https://avatars.githubusercontent.com/u/21222704?v=4'
status: 'published'
title: 'Singing Bunny Stuffed Animal '
publishedAt: '2023-10-27T03:49:46.100Z'
---

• **Interactive & Entertaining**: Flora the Bunny features two play modes. Press her left foot for a game of peek-a-boo with her oversized ears, or press her right foot to enjoy a cute song while her ears flap to the rhythm. Suitable for ages 0+ and has enhanced audio and volume controls.

• **Made with Care**: Crafted by GUND, America's oldest soft toy maker with 125 years of experience. Known for their huggable designs and unmatched quality, the toy is also covered by the Spin Master Care Commitment for added assurance.

