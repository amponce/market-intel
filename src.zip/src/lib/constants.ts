export const EXAMPLE_PATH = 'blog-starter'
